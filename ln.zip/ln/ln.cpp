/* -*- Mode: C++; -*-
 *                            
 * ln.cpp                     Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The ln is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 */


#include <stdio.h>

#include "CreateLink.h"

#include <direct.h>

bool GetEntirePath(LPSTR path)
{
	bool bHasChanged = false;
	if(path[0] == '.')
	{
		int i =0;
		bHasChanged = true;

		char buffer[_MAX_PATH];

		if(path[1] == '.')
		{
			i ++;
//			chdir("..");
			_chdir("..");
		}

		LPTSTR curDir = new TCHAR[_MAX_PATH];
		GetCurrentDirectory(_MAX_PATH, curDir);

//		strcpy(buffer, curDir);
		strcpy_s(buffer, _MAX_PATH, curDir);
//		strcat(buffer, &path[i]);
		strcat_s(buffer, _MAX_PATH, &path[i]);

//		strcpy(path, buffer);
		strcpy_s(path, _MAX_PATH, buffer);
	}

	return bHasChanged;
}

void main(int argc, char** argv)
{
//CreateLink necessite des chemins absolus
	GetEntirePath(argv[2]);
	GetEntirePath(argv[3]);

	if(argc != 4 || strcmp(argv[1], "-s") != 0)
	{
		fprintf(stderr, "Usage : ln -s ObjectPath LinkPath\n");
		MessageBox( NULL, "ln -s ObjectPath LinkPath", "ln Usage", MB_OK | MB_ICONINFORMATION);
	}
	else
	{
		    HRESULT hres = CreateLink(argv[2], argv[3]);
			if (!SUCCEEDED(hres))
			{
				char* line;
				size_t lineSize = 0;
				for(int i = 0; i < argc; i++)
				{
					lineSize += strlen(argv[i]);
				}
				lineSize += argc;
				line = new char[lineSize];
				line[0] = '\0';
				for(int i = 0; i < argc; i++)
				{
//					strcat(line, argv[i]);
					strcat_s(line, lineSize, argv[i]);
//					strcat(line, " ");
					strcat_s(line, lineSize, " ");
				}
				line[lineSize] = '\0';

				char *msg = new char[lineSize + strlen(" : Failed") + 1];
//				sprintf(msg, "%s%s", line, " : Failed");
				sprintf_s(msg, lineSize + strlen(" : Failed") + 1, "%s%s", line, " : Failed");
				fprintf(stderr, msg);
				MessageBox( NULL, msg, "ln Error", MB_OK | MB_ICONINFORMATION );
				delete []msg;
				delete []line;
			}
	}
}