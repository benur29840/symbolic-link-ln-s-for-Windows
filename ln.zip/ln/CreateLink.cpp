/* -*- Mode: C++; -*-
 *                            
 * CreateLink.cpp             Created on: 2016/11/09
 *                            Author    : Rock Benoit
 *
 *    Copyright (C) 2016 Rock's Architecture
 *
 * 
 *    The ln is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU Library General Public
 *    License along with this library; if not, write to the Free
 *    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
 *    02111-1307, USA
 *
 *
 */


#include <shlobj.h>
#include <string.h>

HRESULT CreateLink(LPCSTR lpszPathObj, 
    LPSTR lpszPathLink) 
{ 
    HRESULT hres; 
    IShellLink* psl; 
	char PathObj[_MAX_PATH];

//	strcpy(PathObj, lpszPathObj);
	strcpy_s(PathObj, _MAX_PATH, lpszPathObj);
 
	for(unsigned int i = 0; i < strlen(PathObj); i++)
	{
		if(PathObj[i] == '/')
			PathObj[i] = '\\';
	}

	for(unsigned int i = 0; i < strlen(lpszPathLink); i++)
	{
		if(lpszPathLink[i] == '/')
			lpszPathLink[i] = '\\';
	}

	hres = CoInitialize(NULL);
	
	if (SUCCEEDED(hres))
	{
		// Get a pointer to the IShellLink interface. 
		hres = CoCreateInstance(CLSID_ShellLink,
								NULL, 
								CLSCTX_INPROC_SERVER,
								IID_IShellLink,
								(LPVOID *)&psl); 
		if (SUCCEEDED(hres))
		{ 
			IPersistFile* ppf; 

			char description[200];

//			strcpy(description, "Shortcut to ");
			strcpy_s(description, 13, "Shortcut to ");
//			strcat(description, PathObj);
			strcat_s(description, MAX_PATH, PathObj);

			// Set the path to the shortcut target, and add the 
			// description. 
			psl->SetPath(PathObj); 
			psl->SetDescription(description); 

		   // Query IShellLink for the IPersistFile interface for saving the 
		   // shortcut in persistent storage. 
			hres = psl->QueryInterface(IID_IPersistFile, (LPVOID *)&ppf); 

			if (SUCCEEDED(hres)) { 
//				WORD wsz[_MAX_PATH];
				WCHAR wsz[_MAX_PATH]; 
				
				// Ensure that the string is ANSI. 
				MultiByteToWideChar(CP_ACP, 0, lpszPathLink, -1, 
					wsz, _MAX_PATH); 

				// Save the link by calling IPersistFile::Save. 
				hres = ppf->Save(wsz, TRUE); 
				ppf->Release(); 
			} 
			psl->Release(); 
		} 
		CoUninitialize();
	}
    return hres; 
} 